import fs from 'fs';
import path from 'path';

export type SupportedTranslationLanguage =
  | 'en'
  | 'hi'
  | 'bn'
  | 'te'
  | 'mr'
  | 'ta'
  | 'gu'
  | 'kn'
  | 'ml'
  | 'pa'
  | 'or'
  | 'as'
  | 'ne'
  | 'ur';

type TranslationCache = {
  version: 3;
  sourceLanguage: 'en';
  translations: Partial<Record<Exclude<SupportedTranslationLanguage, 'en'>, Record<string, string>>>;
};

const CACHE_FILE = path.resolve(
  process.env.TRANSLATION_CACHE_FILE || 'data/translations-cache-v2.json'
);
const REQUEST_TIMEOUT_MS = 10000;
const FAILURE_COOLDOWN_MS = 30000;
const MAX_CONCURRENT_REQUESTS = 1;
const MIN_REQUEST_INTERVAL_MS = 1200;
const MAX_RETRIES = 3;
const MAX_TEXT_LENGTH = 1000;

const pendingRequests = new Map<string, Promise<string>>();
const failedUntil = new Map<string, number>();

const queue: Array<{
  key: string;
  text: string;
  language: Exclude<SupportedTranslationLanguage, 'en'>;
  resolve: (value: string) => void;
  reject: (reason?: unknown) => void;
}> = [];

let activeRequests = 0;
let cache: TranslationCache | null = null;
let lastRequestStartedAt = 0;
let queueTimer: ReturnType<typeof setTimeout> | null = null;

function createEmptyCache(): TranslationCache {
  return {
    version: 3,
    sourceLanguage: 'en',
    translations: {}
  };
}

function ensureCacheLoaded(): TranslationCache {
  if (cache) return cache;

  try {
    if (!fs.existsSync(CACHE_FILE)) {
      cache = createEmptyCache();
      return cache;
    }

    const parsed = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')) as Partial<TranslationCache>;

    // Version 3 intentionally invalidates the old bundled/runtime cache so that
    // no pre-generated translations are shipped with the application.
    if (
      parsed.version !== 3 ||
      parsed.sourceLanguage !== 'en' ||
      !parsed.translations ||
      typeof parsed.translations !== 'object'
    ) {
      cache = createEmptyCache();
      return cache;
    }

    cache = {
      version: 3,
      sourceLanguage: 'en',
      translations: parsed.translations
    };
  } catch (error) {
    console.error('[Translation] Failed to read cache; starting empty:', error);
    cache = createEmptyCache();
  }

  return cache;
}

function persistCache(): void {
  const currentCache = ensureCacheLoaded();

  try {
    fs.mkdirSync(path.dirname(CACHE_FILE), { recursive: true });
    const temporaryFile = `${CACHE_FILE}.tmp`;
    fs.writeFileSync(temporaryFile, JSON.stringify(currentCache, null, 2), 'utf8');
    fs.renameSync(temporaryFile, CACHE_FILE);
  } catch (error) {
    console.error('[Translation] Failed to persist cache:', error);
  }
}

function cacheKey(text: string, language: Exclude<SupportedTranslationLanguage, 'en'>): string {
  return `en:${language}:${text}`;
}

function getCachedTranslation(
  text: string,
  language: Exclude<SupportedTranslationLanguage, 'en'>
): string | undefined {
  return ensureCacheLoaded().translations[language]?.[text];
}

function setCachedTranslation(
  text: string,
  language: Exclude<SupportedTranslationLanguage, 'en'>,
  translatedText: string
): void {
  const currentCache = ensureCacheLoaded();
  currentCache.translations[language] ??= {};
  currentCache.translations[language]![text] = translatedText;
  persistCache();
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function requestFromMyMemory(
  text: string,
  language: Exclude<SupportedTranslationLanguage, 'en'>
): Promise<string> {
  let lastError: unknown;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    try {
      const url = new URL('https://api.mymemory.translated.net/get');
      url.searchParams.set('q', text);
      url.searchParams.set('langpair', `en|${language}`);

      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          Accept: 'application/json',
          'User-Agent': 'TribalScholar/1.0 translation-client'
        }
      });

      if (response.status === 429) {
        lastError = new Error('MyMemory returned HTTP 429');
        if (attempt < MAX_RETRIES) {
          const delay = 2000 * 2 ** attempt;
          console.warn(`[Translation] MyMemory rate limited ${language}; retrying in ${delay}ms.`);
          await wait(delay);
          continue;
        }
        throw lastError;
      }

      if (!response.ok) {
        throw new Error(`MyMemory returned HTTP ${response.status}`);
      }

      const payload = await response.json() as {
        responseData?: { translatedText?: string };
        responseStatus?: number;
        quotaFinished?: boolean;
      };

      if (payload.responseStatus === 429 || payload.quotaFinished) {
        lastError = new Error('MyMemory rate limit/quota reached');
        if (attempt < MAX_RETRIES) {
          const delay = 2000 * 2 ** attempt;
          console.warn(`[Translation] MyMemory quota/rate limit for ${language}; retrying in ${delay}ms.`);
          await wait(delay);
          continue;
        }
        throw lastError;
      }

      const translatedText = payload.responseData?.translatedText?.trim();
      if (!translatedText) {
        throw new Error('MyMemory returned no usable translation');
      }

      return translatedText;
    } catch (error) {
      lastError = error;
      const isAbort = error instanceof Error && error.name === 'AbortError';
      if (attempt < MAX_RETRIES && isAbort) {
        await wait(1000 * 2 ** attempt);
        continue;
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  throw lastError instanceof Error ? lastError : new Error('MyMemory translation failed');
}

function processQueue(): void {
  if (queueTimer || activeRequests >= MAX_CONCURRENT_REQUESTS || queue.length === 0) return;

  const elapsed = Date.now() - lastRequestStartedAt;
  const waitFor = Math.max(0, MIN_REQUEST_INTERVAL_MS - elapsed);

  if (waitFor > 0) {
    queueTimer = setTimeout(() => {
      queueTimer = null;
      processQueue();
    }, waitFor);
    return;
  }

  const item = queue.shift();
  if (!item) return;

  activeRequests += 1;
  lastRequestStartedAt = Date.now();

  requestFromMyMemory(item.text, item.language)
    .then((translatedText) => {
      failedUntil.delete(item.key);
      setCachedTranslation(item.text, item.language, translatedText);
      item.resolve(translatedText);
    })
    .catch((error) => {
      failedUntil.set(item.key, Date.now() + FAILURE_COOLDOWN_MS);
      item.reject(error);
    })
    .finally(() => {
      activeRequests -= 1;
      pendingRequests.delete(item.key);
      processQueue();
    });
}

export function isSupportedTranslationLanguage(value: string): value is SupportedTranslationLanguage {
  return ['en', 'hi', 'bn', 'te', 'mr', 'ta', 'gu', 'kn', 'ml', 'pa', 'or', 'as', 'ne', 'ur'].includes(value);
}

export async function translateText(
  text: string,
  language: SupportedTranslationLanguage
): Promise<{ text: string; cached: boolean }> {
  const normalizedText = text.trim();

  if (!normalizedText || language === 'en') {
    return { text, cached: true };
  }

  if (normalizedText.length > MAX_TEXT_LENGTH) {
    return { text, cached: false };
  }

  const targetLanguage = language as Exclude<SupportedTranslationLanguage, 'en'>;
  const cachedTranslation = getCachedTranslation(normalizedText, targetLanguage);

  if (cachedTranslation) {
    return { text: cachedTranslation, cached: true };
  }

  const key = cacheKey(normalizedText, targetLanguage);
  const existingRequest = pendingRequests.get(key);
  if (existingRequest) {
    return { text: await existingRequest, cached: false };
  }

  if ((failedUntil.get(key) || 0) > Date.now()) {
    return { text, cached: false };
  }

  const request = new Promise<string>((resolve, reject) => {
    queue.push({
      key,
      text: normalizedText,
      language: targetLanguage,
      resolve,
      reject
    });
    processQueue();
  });

  pendingRequests.set(key, request);

  try {
    return { text: await request, cached: false };
  } catch (error) {
    console.error(`[Translation] MyMemory request failed for ${targetLanguage}:`, error);
    return { text, cached: false };
  }
}
